#include "uart.h"

void uart0_init()