#ifndef _LED_H
#define _LED_H

void led_flash(void);
void Interrupt_Init(void);

#endif

