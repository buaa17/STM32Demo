#ifndef _USART1_H
#define _USART1_H

void USART1_Config(void);

#endif

