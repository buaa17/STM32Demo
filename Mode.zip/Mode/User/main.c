#include "stm32f10x.h"
#include "delay.h"

int main()
{

}